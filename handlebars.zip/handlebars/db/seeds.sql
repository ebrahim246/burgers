USE burgers_db;
-- Insert new rows of data.
INSERT INTO burgers (burger_name, devoured) VALUES ("hamburger", false);
INSERT INTO burgers (burger_name, devoured) VALUES ("cheeseburger", false);
INSERT INTO burgers (burger_name, devoured) VALUES ("impossible burger", false);